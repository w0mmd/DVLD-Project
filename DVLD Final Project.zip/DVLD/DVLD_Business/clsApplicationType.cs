﻿using System;
using DVLD_DataAccess;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DVLD_Business
{
    public class clsApplicationType
    {
        public int ApplicationTypeID {  get; set; }
        public string ApplicationTypeTitle { get; set; }
        public decimal ApplicationTypeFees { get; set; }

        private clsApplicationType(int ApplicationTypeID,
            string ApplicationTypeTitle, decimal ApplicationTypeFees)
        {
            this.ApplicationTypeID = ApplicationTypeID;
            this.ApplicationTypeTitle = ApplicationTypeTitle;
            this.ApplicationTypeFees = ApplicationTypeFees;
        }

        public static DataTable GetAllApplicationTypes()
        {
            return clsApplicationTypeData.GetAllApplicationType();
        }

        public bool UpdateApplicationTypes()
        {
            return clsApplicationTypeData.UpdateApplicationType(this.ApplicationTypeID,
                this.ApplicationTypeTitle, this.ApplicationTypeFees);
        }

        public static clsApplicationType GetApplicationTypeByID(int ID)
        {
            string Title = ""; decimal Fees = -1;

            if(clsApplicationTypeData.GetApplicationTypeInfoByID(ID, ref Title, ref Fees))
            {
                return new clsApplicationType(ID, Title, Fees);
            }
            else
            {
                return null;
            }
        }
    }
}
