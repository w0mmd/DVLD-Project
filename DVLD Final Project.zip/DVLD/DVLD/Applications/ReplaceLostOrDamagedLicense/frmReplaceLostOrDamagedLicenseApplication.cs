﻿using DVLD.Global_Classes;
using DVLD.Licenses.International_Licenses.Controls;
using DVLD.Licenses.Local_Licenses;
using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Applications.ReplaceLostOrDamagedLicense
{
    public partial class frmReplaceLostOrDamagedLicenseApplication : Form
    {
        int _NewLicenseID = -1;
        public frmReplaceLostOrDamagedLicenseApplication()
        {
            InitializeComponent();
        }

        private void frmReplaceLostOrDamagedLicenseApplication_Load(object sender, EventArgs e)
        {
            ctrlDriverLicenseInfoWithFilter1.OnLicenseSelected += ctrlDriverLicenseInfoWithFilter1_OnLicenseSelected;
        }

        private void ctrlDriverLicenseInfoWithFilter1_OnLicenseSelected(int obj)
        {
            int _LicenseID = obj;
            lblOldLicenseID.Text = _LicenseID.ToString();
            lblAppDate.Text = DateTime.Now.ToShortDateString();
            lblCreatedBy.Text = clsGlobal.CurrentUser.UserName.ToString();

            if(_LicenseID == -1)
            {
                return;
            }

            if (!ctrlDriverLicenseInfoWithFilter1.SelectedLicenseInfo.IsActive)
            {
                MessageBox.Show("License is not active!", "Active License",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnIssue.Enabled = false;
                return;
            }

            btnIssue.Enabled = true;
            llblShowNewLicenseInfo.Enabled = false;
            llblShowLicenseHistory.Enabled = false;

        }

        private void btnIssue_Click(object sender, EventArgs e)
        {
            if(!rbDamagedLicense.Checked && !rbLostLicense.Checked)
            {
                MessageBox.Show("Issue reason must be selected!", "Error",
      MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            clsLicense.enIssueReason reason;

            if (rbDamagedLicense.Checked)
                reason = clsLicense.enIssueReason.DamagedReplacement;
            else
                reason = clsLicense.enIssueReason.LostReplacement;

            clsLicense ReplacedLicense = 
                ctrlDriverLicenseInfoWithFilter1.SelectedLicenseInfo.Replace(reason, clsGlobal.CurrentUser.UserID);

            if (ReplacedLicense == null)
            {
                MessageBox.Show("Replacement failed!", "Error",
           MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MessageBox.Show("Replacement done successfullay!", "Confirmed",
        MessageBoxButtons.OK, MessageBoxIcon.Information);

            _NewLicenseID = ReplacedLicense.LicenseID;
            lblRenewAppID.Text = ReplacedLicense.ApplicationID.ToString();
            lblRenewedLicenseID.Text = ReplacedLicense.LicenseID.ToString();

            btnIssue.Enabled = false;
            llblShowNewLicenseInfo.Enabled = true;
            llblShowLicenseHistory.Enabled = true;
            ctrlDriverLicenseInfoWithFilter1.FilterEnabled = false;

        }

        private void llblShowNewLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form frm = new frmShowLicenseInfo(_NewLicenseID);
            frm.ShowDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void rbDamagedLicense_CheckedChanged(object sender, EventArgs e)
        {
            lblTitle.Text = "Replacement For Damaged License";
            this.Text = lblTitle.Text;
            lblAppFees.Text = clsApplicationType.GetApplicationTypeByID(_GetApplicationTypeID()).ApplicationTypeFees.ToString();

        }

        private void rbLostLicense_CheckedChanged(object sender, EventArgs e)
        {
            lblTitle.Text = "Replacement For Lost License";
            this.Text = lblTitle.Text;
            lblAppFees.Text = clsApplicationType.GetApplicationTypeByID(_GetApplicationTypeID()).ApplicationTypeFees.ToString();

        }

        private int _GetApplicationTypeID()
        {
            if (rbDamagedLicense.Checked)
                return (int)clsApplication.enApplicationType.ReplaceDamagedDrivingLicense;
            else
                return (int)clsApplication.enApplicationType.ReplaceLostDrivingLicense;
        }
    }
}
