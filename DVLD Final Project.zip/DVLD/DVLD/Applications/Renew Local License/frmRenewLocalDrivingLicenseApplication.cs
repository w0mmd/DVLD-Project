﻿using DVLD.Global_Classes;
using DVLD.Licenses.Local_Licenses;
using DVLD.Licenses.Local_Licenses.Controls;
using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Applications.Renew_Local_License
{
    public partial class frmRenewLocalDrivingLicenseApplication : Form
    {
        int _NewLicenseID = -1;
        clsLicense _License;
        public frmRenewLocalDrivingLicenseApplication()
        {
            InitializeComponent();
        }

        private void frmRenewLocalDrivingLicenseApplication_Load(object sender, EventArgs e)
        {
            ctrlDriverLicenseInfoWithFilter1.OnLicenseSelected += ctrlDriverLicenseInfoWithFilter1_OnLicenseSelected;


        }

        private void _FillAllFields()
        {
            
            lblAppDate.Text = DateTime.Now.ToShortDateString();
            lblIssueDate.Text = DateTime.Now.ToShortDateString();
            lblAppFees.Text = clsApplicationType.GetApplicationTypeByID((int)clsApplication.enApplicationType.RenewDrivingLicense).ApplicationTypeFees.ToString();
            lblLicenseFees.Text = clsLicenseClasses.Find(_License.LicenseClassIfo.LicenseClassID).ClassFees.ToString();
            lblOldLicenseID.Text = _License.LicenseID.ToString();
            lblExpirationDate.Text = DateTime.Now.AddYears(_License.LicenseClassIfo.DefaultValidityLength).ToShortDateString();
            lblCreatedBy.Text = clsGlobal.CurrentUser.UserName.ToString();
            lblTotalFees.Text = (float.Parse(lblAppFees.Text) + float.Parse(lblLicenseFees.Text)).ToString();


        }

        private void ctrlDriverLicenseInfoWithFilter1_OnLicenseSelected(int obj)
        {
            int _LicenseID = obj;
            _License = clsLicense.Find(_LicenseID);

            if (_License == null)
                return;

            llblShowLicenseHistory.Enabled = (_LicenseID != -1);
            if (_License.ExpirationDate > DateTime.Now)
            {
                MessageBox.Show("License is still active and not expired yet!", "Active License",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnRenew.Enabled = false;
                return;
            }
            if (!_License.IsActive)
            {
                MessageBox.Show("License is not active!", "Active License",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnRenew.Enabled = false;
                return;
            }
            btnRenew.Enabled = true;

            _FillAllFields();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRenew_Click(object sender, EventArgs e)
        {
           clsLicense NewLicense = _License.RenewLicense(txtNotes.Text.Trim(), clsGlobal.CurrentUser.UserID);
           
            if(NewLicense == null)
            {
                MessageBox.Show(
            "Failed to renew the license.",
            "Error",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error);
                return;
            }
            MessageBox.Show(
            "License renewed successfully.\nNew License ID = " + NewLicense.LicenseID,
            "Success",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);
            _NewLicenseID = NewLicense.LicenseID;
            lblRenewAppID.Text = NewLicense.ApplicationID.ToString();
            lblRenewedLicenseID.Text = NewLicense.LicenseID.ToString();

            btnRenew.Enabled = false;
            ctrlDriverLicenseInfoWithFilter1.Enabled = false;
        }

        private void llblShowNewLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           Form frm = new frmShowLicenseInfo(_NewLicenseID);
            frm.ShowDialog();
        }
    }
}
