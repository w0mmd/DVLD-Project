﻿using DVLD.People;
using DVLD.People.Controls;
using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Applications.Local_Driving_License
{
    public partial class ctrlDrivingLicenseApplicationInfo : UserControl
    {
        int _LocalDrivingLicenseApplicationID = -1;
        clsLocalDrivingLicenseApplication _LocalDrivingLicenseApplication;

        public int LocalDrivingLicenseApplicationID
        {
            get {  return _LocalDrivingLicenseApplicationID;}
        }

        public ctrlDrivingLicenseApplicationInfo()
        {
            InitializeComponent();
        }

        private void ctrlDrivingLicenseApplicationInfo_Load(object sender, EventArgs e)
        {

        }

        private void _ResetAllValuesToDefault()
        {
            lblDLAppID.Text = "";
            lblAppliedForLicense.Text = "";
            lblPassedTests.Text = "";
            llblShowLicenseInfo.Text = "";
            
        }

        public void LoadDataByLocalApplicationID(int LocalDrivingLicenseApplicationID)
        {
            this._LocalDrivingLicenseApplicationID = LocalDrivingLicenseApplicationID;

            _LocalDrivingLicenseApplication = clsLocalDrivingLicenseApplication.FindByLocalDrivingAppLicenseID(this._LocalDrivingLicenseApplicationID);

            if(_LocalDrivingLicenseApplication == null)
            {
                _ResetAllValuesToDefault();
                MessageBox.Show("No Application is found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _FillApplicationInfoToCTRL();

        }
        public void LoadDataByApplicationID(int ApplicationID)
        {
            this._LocalDrivingLicenseApplicationID = LocalDrivingLicenseApplicationID;

            _LocalDrivingLicenseApplication = clsLocalDrivingLicenseApplication.FindByApplicationID(ApplicationID);

            if(_LocalDrivingLicenseApplication == null)
            {
                _ResetAllValuesToDefault();
                MessageBox.Show("No Application is found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _FillApplicationInfoToCTRL();

        }

        private void _FillApplicationInfoToCTRL()
        {
           lblDLAppID.Text = _LocalDrivingLicenseApplication.LocalDrivingLicenseApplicationID.ToString();
            lblAppliedForLicense.Text = _LocalDrivingLicenseApplication.LicenseClassInfo.ClassName;

            ctrlApplicationBasicInfo1.LoadData(_LocalDrivingLicenseApplication.ApplicationID);
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void ctrlApplicationBasicInfo1_Load(object sender, EventArgs e)
        {

        }
    }
}
