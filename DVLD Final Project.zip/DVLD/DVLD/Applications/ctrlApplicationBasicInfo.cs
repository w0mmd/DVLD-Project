﻿using DVLD.People;
using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Applications
{
    public partial class ctrlApplicationBasicInfo : UserControl
    {
        int _ApplicationID = -1;
        clsApplication _Application;

        public int ApplicationID
        {
            get { return _ApplicationID; }
        }

        public ctrlApplicationBasicInfo()
        {
            InitializeComponent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void ctrlApplicationBasicInfo_Load(object sender, EventArgs e)
        {

        }

        private void _ResetAllValuesToDefault()
        {
            lblID.Text = "";
            lblStatus.Text = "";
            lblFees.Text = "";
            lblType.Text = "";
            lblApplicant.Text = "";
            lblDate.Text = "";
            lblStatusDate.Text = "";
            lblCreatedBy.Text = "";
            llblShowPersonInfo.Text = "";
        }

        public void LoadData(int ApplicationID)
        {
            _Application = clsApplication.FindBaseApplication(ApplicationID);

            if( _Application == null)
            {
                _ResetAllValuesToDefault();
                MessageBox.Show("No Application is found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            this._ApplicationID = ApplicationID;
            _FillApplicationInfo();
        }

        private void _FillApplicationInfo()
        {
            lblID.Text = _Application.ApplicationID.ToString();
            lblStatus.Text = _Application.StatusText;
            lblFees.Text = _Application.PaidFees.ToString();
            lblType.Text = _Application.ApplicationTypeInfo.ApplicationTypeTitle;
            lblApplicant.Text = _Application.ApplicantFullName;
            lblDate.Text = _Application.ApplicationDate.ToShortDateString();
            lblStatusDate.Text = _Application.LastStatusDate.ToShortDateString();
            lblCreatedBy.Text = _Application.CreatedByUserID.ToString();

        }

        private void llblShowPersonInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form frmShowPersonInfo = new frmShowPersonInfo(_Application.ApplicantPersonID);
            frmShowPersonInfo.ShowDialog();
        }
    }
}
