﻿using DVLD.Applications.Local_Driving_License;
using DVLD.Licenses.Local_Licenses;
using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Licenses.Controls
{
    public partial class ctrlDriverLicenses : UserControl
    {
        int _DriverID = -1;
        clsDriver _Driver;
        DataTable _dtLocalLicensesHistory;
        DataTable _dtInternationalLicensesHistory;
        public ctrlDriverLicenses()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        public void _LoadData(int DriverID)
        {  
            _DriverID = DriverID;
            _Driver = clsDriver.FindByDriverID(_DriverID);

            if( _Driver == null )
            {
                MessageBox.Show("No driver with id [" + _DriverID + "] is found!",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            _LoadDriverLocalLicenses();
            _LoadDriverInternationalLicenses();
        }

        public void _LoadDataByPersonID(int PersonID)
        {
            _Driver = clsDriver.FindByPersonID(PersonID);

                if (_Driver == null)
                {
                    MessageBox.Show("No driver is linked with person with id [" + PersonID + "] is found!",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

            _DriverID = _Driver.DriverID;
            _LoadDriverLocalLicenses();
            _LoadDriverInternationalLicenses();
        }

        public void Clear()
        {
            if (_dtLocalLicensesHistory != null)
                _dtLocalLicensesHistory.Clear();

            dgvLocalLicenses.DataSource = null;
            lblRecords.Text = "0";
        }

        private void _LoadDriverLocalLicenses()
        {
            _dtLocalLicensesHistory = clsDriver.GetLicenses(_DriverID);
            dgvLocalLicenses.DataSource = _dtLocalLicensesHistory;
            lblRecords.Text = dgvLocalLicenses.Rows.Count.ToString();

            if (dgvLocalLicenses.Rows.Count > 0)
            {
                dgvLocalLicenses.Columns[0].HeaderText = "Lic.ID";
                dgvLocalLicenses.Columns[0].Width = 50;

                dgvLocalLicenses.Columns[1].HeaderText = "App.ID";
                dgvLocalLicenses.Columns[1].Width = 50;

                dgvLocalLicenses.Columns[2].HeaderText = "Class Name";
                dgvLocalLicenses.Columns[2].Width = 150;

                dgvLocalLicenses.Columns[3].HeaderText = "Issue Date";
                dgvLocalLicenses.Columns[3].Width = 150;

                dgvLocalLicenses.Columns[4].HeaderText = "Expiration Date";
                dgvLocalLicenses.Columns[4].Width = 150;

                dgvLocalLicenses.Columns[5].HeaderText = "Active";
                dgvLocalLicenses.Columns[5].Width = 50;
            }
        }
        private void _LoadDriverInternationalLicenses()
        {
            _dtInternationalLicensesHistory = clsInternationalLicense.GetDriverInternationalLicenses(_DriverID);
            dgvInternationalLicenses.DataSource = _dtInternationalLicensesHistory;
            lblRecords.Text = dgvInternationalLicenses.Rows.Count.ToString();

            if (dgvInternationalLicenses.Rows.Count > 0)
            {
                dgvInternationalLicenses.Columns[0].HeaderText = "Int.License ID";
                dgvInternationalLicenses.Columns[0].Width = 160;
                
                dgvInternationalLicenses.Columns[1].HeaderText = "Application ID";
                dgvInternationalLicenses.Columns[1].Width = 130;
                
                dgvInternationalLicenses.Columns[2].HeaderText = "L.License ID";
                dgvInternationalLicenses.Columns[2].Width = 130;
                
                dgvInternationalLicenses.Columns[3].HeaderText = "Issue Date";
                dgvInternationalLicenses.Columns[3].Width = 180;
                
                dgvInternationalLicenses.Columns[4].HeaderText = "Expiration Date";
                dgvInternationalLicenses.Columns[4].Width = 180;
                
                dgvInternationalLicenses.Columns[5].HeaderText = "Is Active";
                dgvInternationalLicenses.Columns[5].Width = 120;
            }
        }

        private void ctrlDriverLicenses_Load(object sender, EventArgs e)
        {

        }

        private void showDriverLicenseInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form frm = new frmShowLicenseInfo((int)dgvLocalLicenses.CurrentRow.Cells[0].Value);
            frm.ShowDialog();
        }
    }
}
