﻿using DVLD.Properties;
using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Licenses.Local_Licenses.Controls
{
    public partial class ctrlDriverLicenseInfo : UserControl
    {
        int _LicenseID = -1;
        clsLicense _License;

        public int LicenseID
        {
            get {  return _LicenseID; }
        }

        public clsLicense SelectedLicenseInfo
        {
            get { return _License; }
        }

        public ctrlDriverLicenseInfo()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void ctrlDriverLicenseInfo_Load(object sender, EventArgs e)
        {

        }

        public void LoadData(int LicenseID)
        {
            _License = clsLicense.Find(LicenseID);

            if(_License == null)
            {
                MessageBox.Show("License is not found!", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            _LicenseID = LicenseID;
            _FillAllFields();
        }

        private void _FillAllFields()
        {
            lblClass.Text = _License.LicenseClassIfo.ClassName;
            lblName.Text = _License.DriverInfo.PersonInfo.FullName;
            lblLicenseID.Text = _License.LicenseID.ToString();
            lblNationalNo.Text = _License.DriverInfo.PersonInfo.NationalNo.ToString();
            lblGender.Text = _License.DriverInfo.PersonInfo.Gender == 0? "Male" : "Female";
            lblIssueDate.Text = _License.IssueDate.ToShortDateString();
            lblIssueReason.Text = _License.IssueReasonText;
            lblNotes.Text = _License.Notes == ""? "No notes" : _License.Notes.ToString();
            lblIsActive.Text = _License.IsActive? "Yes" : "No";
            lblDateOfBirth.Text = _License.DriverInfo.PersonInfo.DateOfBirth.ToShortDateString().ToLower();
            lblDriverID.Text = _License.DriverID.ToString();
            lblExpirationDate.Text = _License.ExpirationDate.ToShortDateString();
            lblIsDetained.Text = clsDetainedLicense.IsLicenseDetained(_LicenseID) == false? "No" : "Yes";
            _ImageHandling();
        }

        private void _ImageHandling()
        {
            if (_License.DriverInfo.PersonInfo.Gender == 0)
                pictureBox4.Image = Resources.boy;
            else
                pictureBox4.Image = Resources.girl;

            string ImagePath = _License.DriverInfo.PersonInfo.ImagePath;
            if(File.Exists(ImagePath))
            {
                pictureBox4.ImageLocation = ImagePath;
            }
            else
            {
                MessageBox.Show("No image is found!", "No Image",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
          



        }
    }
}
