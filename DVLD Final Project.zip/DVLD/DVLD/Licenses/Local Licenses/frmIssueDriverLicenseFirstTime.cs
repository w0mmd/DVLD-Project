﻿using DVLD.Global_Classes;
using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Licenses.Local_Licenses
{
    public partial class frmIssueDriverLicenseFirstTime : Form
    {
        int _LocalDrivingApplicationID = -1;
        clsLocalDrivingLicenseApplication localDrivingLicenseApplication;
        public frmIssueDriverLicenseFirstTime(int LocalDrivingApplicationID)
        {
            InitializeComponent();
            _LocalDrivingApplicationID = LocalDrivingApplicationID;
        }

        private void frmIssueDriverLicenseFirstTime_Load(object sender, EventArgs e)
        {
            localDrivingLicenseApplication = clsLocalDrivingLicenseApplication.FindByLocalDrivingAppLicenseID(_LocalDrivingApplicationID);

            if(localDrivingLicenseApplication == null )
            {
                MessageBox.Show("No application is found!", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            if(localDrivingLicenseApplication.PassedAllTests())
            {
                MessageBox.Show("All tests must be passed!", "Error",
                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }
            int LicenseID = localDrivingLicenseApplication.GetActiveLicenseID();
            if (LicenseID != -1)
            {
                MessageBox.Show("An active license has been already issued!", "Error",
                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            ctrlDrivingLicenseApplicationInfo1.LoadDataByLocalApplicationID(_LocalDrivingApplicationID);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnIssue_Click(object sender, EventArgs e)
        {
            int LicenseID = localDrivingLicenseApplication.IssueLicenseForFirstTime(txtNotes.Text.Trim(), clsGlobal.CurrentUser.UserID);

            if (LicenseID != -1)
            {
                MessageBox.Show("License issued successfullay with id [" + LicenseID + "].", "Issued",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
      
                    MessageBox.Show("Proccess is failed!", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
        }
    }
}
