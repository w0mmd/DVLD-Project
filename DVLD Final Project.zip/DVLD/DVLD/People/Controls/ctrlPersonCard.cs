﻿using DVLD.Properties;
using DVLD_Business;
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.People.Controls
{
    public partial class ctrlPersonCard : UserControl
    {
        clsPerson person;
        int _PersonID = -1;

        public int PersonID
        {
            get { return _PersonID; }
        }

        public clsPerson SelectedPersonInfo
        {
            get { return person; }
        }

        public ctrlPersonCard()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        public void LoadData(int PersonID)
        {
            ResetValuesToDefault();
             person = clsPerson.Find(PersonID);

            if(person == null)
            {
                MessageBox.Show("No person with ID [" + PersonID.ToString() + "] is found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            _PersonID = PersonID;
            _FillPersonInfo();
                     
        }
        public void LoadData(string NationalNo)
        {
             person = clsPerson.Find(NationalNo);

            if(person == null)
            {
                MessageBox.Show("No person with ID [" + NationalNo + "] is found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _FillPersonInfo();
                     
        }

        private void _FillPersonInfo()
        {
            lblAddress.Text = person.Address;
            lblDateOfBirth.Text = person.DateOfBirth.ToString("dd/mm/yyyy");
            lblName.Text = person.FirstName + " " + person.SecondName + " " + person.ThirdName + " " + person.LastName;
            lblNationalNo.Text = person.NationalNo;
            lblPersonID.Text = person.PersonID.ToString();
            lblPhone.Text = person.Phone;
            lblEmail.Text = person.Email;
            lblCountry.Text = clsCountry.Find(person.CountryID).CountryName;
            lblGender.Text = person.Gender.ToString() == "1" ? "Female" : "Male";
            _LoadPersonImage();
            _PersonID = person.PersonID;
           
        }

        private void _LoadPersonImage()
        {
                pictureBox4.Image = person.Gender == 0 ?
                    Resources.boy : Resources.girl;

            string ImagePath = person.ImagePath;
            if (ImagePath != "" )
            {
                if(File.Exists(ImagePath))
                {
                    pictureBox4.ImageLocation = ImagePath;
                }
                else
                {
                    MessageBox.Show("Could not find this image: " + ImagePath, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            
        }

        private void llblEditPersonInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmAddUpdatePerson  frm = new frmAddUpdatePerson(_PersonID);

            frm.DataBack += LoadData_DataBack;

            frm.ShowDialog();

            //or by using this method instead of delegate...
            //LoadData(_PersonID);
        }

        private void LoadData_DataBack(object sender, int PersonID)
        {
            LoadData(_PersonID);

        }

        public void ResetValuesToDefault()
        {
            lblPersonID.Text = "";
            lblNationalNo.Text = "";
            lblEmail.Text = "";
            lblPhone.Text = "";
            lblGender.Text = "";
            lblAddress.Text = "";
            lblCountry.Text = "";
            lblDateOfBirth.Text = "";
            if (pictureBox4 != null)
            {
                pictureBox4.Image = null;
                pictureBox4.ImageLocation = "";
            }
        }
    }
}
