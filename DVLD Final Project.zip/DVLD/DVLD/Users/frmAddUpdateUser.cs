﻿using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Users
{
    public partial class frmAddUpdateUser : Form
    {
        enum enMode { AddNew = 0, Update = 1};
        enMode Mode;
        int _UserID = 0;
        clsUser user;

        public frmAddUpdateUser(int UserID)
        {
            InitializeComponent();
            _UserID = UserID;
            Mode = enMode.Update;
        }
        public frmAddUpdateUser()
        {
            InitializeComponent();
            Mode = enMode.AddNew;
        }

        private void frmAddUpdateUser_Load(object sender, EventArgs e)
        {
            _ResetAllValuesToDefault();

            if(Mode == enMode.Update)
                _LoadData();
        }

        private void _ResetAllValuesToDefault()
        {
            if(Mode == enMode.AddNew)
            {
                lblModeName.Text = "Add New User";
                 user = new clsUser();
                tabControl1.SelectedTab = PersonalInfo; 
            }
            else
            {
                lblModeName.Text = "Update User";
            }

            ctrlPersonCardWithFilter1.ResetValuesToDefault();

            lblUserID.Text = "";
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtConfirmPassword.Text = "";
            cbIsActive.Checked = false;

        }

        private void _LoadData()
        {
            user = clsUser.Find(_UserID);

            if(user == null)
            {
                MessageBox.Show("No user with ID [" + _UserID + "] is found!", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            ctrlPersonCardWithFilter1.LoadPersonInfo(user.PersonID);
            ctrlPersonCardWithFilter1.FilterEnabled = false;

            lblUserID.Text = user.UserID.ToString();
            txtUsername.Text = user.UserName.ToString();
            txtPassword.Text = user.Password.ToString();
            txtConfirmPassword.Text = user.Password.ToString();
            cbIsActive.Checked = user.IsActive;

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (Mode == enMode.AddNew)
            {
                if (ctrlPersonCardWithFilter1.SelectedPersonInfo == null)
                {
                    MessageBox.Show("Selected person not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (clsUser.DoesPersonHaveUser(ctrlPersonCardWithFilter1.SelectedPersonInfo.PersonID))
                {
                    MessageBox.Show("Selected person is already a user! Choose another person.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

                tabControl1.SelectedTab = tabPage2;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(Mode == enMode.AddNew)
            {
                user.PersonID = ctrlPersonCardWithFilter1.SelectedPersonInfo.PersonID;
            }

            if(txtPassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("Password and Confirm Password fields do not match!", "Validation Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            user.UserName = txtUsername.Text;
            user.Password = txtPassword.Text;
            user.IsActive = cbIsActive.Checked;

            if(user.Save())
            {
                MessageBox.Show("Saved successfully!", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lblModeName.Text = "Update User";
                lblUserID.Text = user.UserID.ToString();
                Mode = enMode.Update;

            }
            else
            {
                MessageBox.Show("Not saved successfully! Check again.", "Save", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
