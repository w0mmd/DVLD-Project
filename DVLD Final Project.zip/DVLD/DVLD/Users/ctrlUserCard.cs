﻿using DVLD.People.Controls;
using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Xsl;

namespace DVLD.Users
{
    public partial class ctrlUserCard : UserControl
    {
        int _UserID = -1;
        public int UserID
        {
            get { return _UserID; }
        }

        clsUser user;

        public clsUser SelectedUserInfo
        {
            get { return user; } 
        }

        public ctrlUserCard()
        {
            InitializeComponent();
        }

        private void ctrlUserCard_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        public void LoadData(int UserID)
        {
            user = clsUser.Find(UserID);

            if(user == null)
            {
                MessageBox.Show("No user with ID [" + _UserID + "] is found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            _UserID = UserID;
            _FillUserInfo();

        }

        private void _FillUserInfo()
        {
            _ResetValuesToDefault();
            ctrlPersonCard1.LoadData(user.PersonID);

            lblUserID.Text = user.UserID.ToString();
            lblUsername.Text = user.UserName.ToString();
            lblIsActive.Text = user.IsActive.ToString();
        }

        private void _ResetValuesToDefault()
        {
            lblIsActive.Text = "";
            lblUsername.Text = "";
            lblUserID.Text = "";
        }

        private void ctrlPersonCard1_Load(object sender, EventArgs e)
        {

        }
    }
}
