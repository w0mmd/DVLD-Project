﻿using DVLD.Global_Classes;
using DVLD.Properties;
using DVLD_Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLD.Tests.Controls
{
    public partial class ctrlScheduleTest : UserControl
    {
        enum enMode { Update = 0, AddNew  = 1 }
        enMode _Mode = enMode.AddNew;

        public enum enCreationMode { FirstTimeSchedule = 0, RetakeTestSchedule = 1 }
        private enCreationMode _CreationMode = enCreationMode.FirstTimeSchedule;

        int _LocalDrivingLicenseApplicationID = -1;
        int _TestAppointmentID = -1;
        clsTestType.enTestType _TestTypeID = clsTestType.enTestType.VisionTest;
        clsLocalDrivingLicenseApplication _LocalDrivingLicenseApplication;
        clsTestAppointment _TestAppointment;

        public clsTestType.enTestType TestTypeID
        {
            get { return _TestTypeID; }
            set
            {
                _TestTypeID = value;

                switch( _TestTypeID )
                {
                    case clsTestType.enTestType.VisionTest:
                        lblTitle.Text = "Vision Test";
                        pictureBox1.Image = Resources.visual_warning2;
                        break;
                    case clsTestType.enTestType.WrittenTest:
                        lblTitle.Text = "Written Test";
                        pictureBox1.Image = Resources.applications;
                        break;
                    case clsTestType.enTestType.StreetTest:
                        lblTitle.Text = "Street Test";
                        pictureBox1.Image = Resources.army_jeep__1_;
                        break;

                }
            }
        }

        public ctrlScheduleTest()
        {
            InitializeComponent();
        
        }
       
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void ctrlScheduleTest_Load(object sender, EventArgs e)
        {

        }

        public void LoadData(int LocalDrivingLicenseApplicationID, int AppointmentID = -1)
        {
            if(AppointmentID == -1)
                _Mode = enMode.AddNew;
            else
                _Mode = enMode.Update;

            _LocalDrivingLicenseApplicationID = LocalDrivingLicenseApplicationID;
            _TestAppointmentID = AppointmentID;
            _LocalDrivingLicenseApplication = clsLocalDrivingLicenseApplication.FindByLocalDrivingAppLicenseID(this._LocalDrivingLicenseApplicationID);

            if( _LocalDrivingLicenseApplication == null )
            {
                MessageBox.Show("No Local Driving License Application with ID [" + _LocalDrivingLicenseApplicationID + "] is found to set an appointment!",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                btnSave.Enabled = false;
                return;
            }

            if(_LocalDrivingLicenseApplication.DoesAttendTestType(_TestTypeID))
                _CreationMode = enCreationMode.RetakeTestSchedule;
            else
                _CreationMode = enCreationMode.FirstTimeSchedule;
            
            if(_CreationMode == enCreationMode.RetakeTestSchedule)
            {
                lblRetakeAppFees.Text = clsApplicationType.GetApplicationTypeByID((int)clsApplication.enApplicationType.RetakeTest).ApplicationTypeFees.ToString();
                groupBox2.Enabled = true;
                lblTitle.Text = "Schedule Retake Test";
                lblRetakeTestAppID.Text = "0";

            }
            else
            {
                groupBox2.Enabled = false;
                lblTitle.Text = "Schedule Test";
                lblRetakeTestAppID.Text = "N/A";
                lblRetakeAppFees.Text = "0";

            }

            lblDLAppID.Text = _LocalDrivingLicenseApplication.LocalDrivingLicenseApplicationID.ToString();
            lblDClass.Text = _LocalDrivingLicenseApplication.LicenseClassInfo.ClassName;
            lblName.Text = _LocalDrivingLicenseApplication.PersonFullName;

            lblTrial.Text = _LocalDrivingLicenseApplication.TotalTrialNumberPerTest(_TestTypeID).ToString();

            if(_Mode == enMode.AddNew)
            {
                lblFees.Text = clsTestType.GetTestTypeByID(_TestTypeID).TestTypeFees.ToString();
                dateTimePicker1.MinDate = DateTime.Now;
                lblRetakeTestAppID.Text = "N/A";

                _TestAppointment = new clsTestAppointment();
            }
            else
            {
                if (!_LoadTestAppointmentData())
                    return;
            }

            float fees = 0, retakeFees = 0;

            float.TryParse(lblFees.Text, out fees);
            float.TryParse(lblRetakeAppFees.Text, out retakeFees);

            lblTotalFees.Text = (fees + retakeFees).ToString();
            // lblTotalFees.Text = (Convert.ToSingle(lblFees.Text) + Convert.ToSingle(lblRetakeAppFees.Text)).ToString();

            if (!_HandleActiveTestAppointmentConstraint())
                return;

            if (!_HandleAppointmentLockedConstraint())
                return;

            if(!_HandlePreviousTestConstraint())
                return;

        }

        private bool _HandlePreviousTestConstraint()
        {
            switch(TestTypeID)
            {
                case clsTestType.enTestType.VisionTest:
                    lblWarning.Visible = false;
                    return true;
                case clsTestType.enTestType.WrittenTest:
                    if(!_LocalDrivingLicenseApplication.DoesPassTestType(clsTestType.enTestType.VisionTest))
                    {
                        lblWarning.Visible = true;
                        lblWarning.Text = "Vision test must be passed first!";
                        btnSave.Enabled = false;
                        dateTimePicker1.Enabled = false;
                        return false;
                    }
                    else
                    {
                        lblWarning.Visible = false;
                        btnSave.Enabled = true;
                        dateTimePicker1.Enabled = true;
                    }
                    return true;
                case clsTestType.enTestType.StreetTest:
                    if (!_LocalDrivingLicenseApplication.DoesPassTestType(clsTestType.enTestType.WrittenTest))
                    {
                        lblWarning.Visible = true;
                        lblWarning.Text = "Written test must be passed first!";
                        btnSave.Enabled = false;
                        dateTimePicker1.Enabled = false;
                        return false;
                    }
                    else
                    {
                        lblWarning.Visible = false;
                        btnSave.Enabled = true;
                        dateTimePicker1.Enabled = true;
                    }
                    return true;
                default:
                    return false;
            }
        }
        private bool _HandleAppointmentLockedConstraint()
        {
            if(_TestAppointment.IsLocked)
            {
                lblWarning.Visible = true;
                lblWarning.Text = "Person has already taken this test, appointment is locked!";
                dateTimePicker1.Enabled = false;
                btnSave.Enabled = false;
                return false;
            }
            else
            {
                lblWarning.Visible = false;
            }

            return true;
        }
        private bool _HandleActiveTestAppointmentConstraint()
        {
            if(_Mode == enMode.AddNew && clsLocalDrivingLicenseApplication.IsThereAnActiveScheduledTest(_LocalDrivingLicenseApplicationID, TestTypeID))
            {
                lblWarning.Text = "Person already has an active test appointment";
                btnSave.Enabled = false;
                dateTimePicker1.Enabled = false;
                return false;

            }

            return true;
        }
        private bool _LoadTestAppointmentData()
        {
            _TestAppointment = clsTestAppointment.Find(_TestAppointmentID);

            if (_TestAppointment == null)
            {
                MessageBox.Show("No Appointment with ID [" + _TestAppointmentID + "] is found to edit!",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                btnSave.Enabled = false;
                return false;
            }

            lblFees.Text = _TestAppointment.PaidFees.ToString();

            if (DateTime.Compare(DateTime.Now, _TestAppointment.AppointmentDate) < 0)
                dateTimePicker1.MinDate = DateTime.Now;
            else
                dateTimePicker1.MinDate = _TestAppointment.AppointmentDate;

            dateTimePicker1.Value = _TestAppointment.AppointmentDate;

            if(_TestAppointment.RetakeTestApplicationID == -1)
            {
                lblRetakeAppFees.Text = "0";
                lblRetakeTestAppID.Text = "N/A";
            }
            else
            {
                lblRetakeAppFees.Text = _TestAppointment.RetakeTestAppInfo.PaidFees.ToString();
                groupBox2.Enabled = true;
                lblTitle.Text = "Schedule Retake Test";
                lblRetakeTestAppID.Text = _TestAppointment.RetakeTestApplicationID.ToString();
            }
            return true;

        }
        private bool _HandleRetakeApplication()
        {
            if(_Mode == enMode.AddNew && _CreationMode == enCreationMode.RetakeTestSchedule)
            {
                clsApplication Application = new clsApplication();

                Application.ApplicantPersonID = _LocalDrivingLicenseApplication.ApplicantPersonID;
                Application.ApplicationDate = DateTime.Now;
                Application.ApplicationTypeID = (int)clsApplication.enApplicationType.RetakeTest;
                Application.ApplicationStatus = clsApplication.enApplicationStatus.Completed;
                Application.LastStatusDate = DateTime.Now;
                Application.PaidFees = (float)clsApplicationType.GetApplicationTypeByID((int)clsApplication.enApplicationType.RetakeTest).ApplicationTypeFees;
                Application.CreatedByUserID = clsGlobal.CurrentUser.UserID;

                if(!Application.Save())
                {
                    _TestAppointment.RetakeTestApplicationID = -1;
                    MessageBox.Show("Failed to create an application", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                _TestAppointment.RetakeTestApplicationID = Application.ApplicationID;
            }
            return true;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (_TestAppointment == null)
                _TestAppointment = new clsTestAppointment();

            if (_Mode == enMode.Update)
                _TestAppointment.TestAppointmentID = _TestAppointmentID; 

            if (!_HandleRetakeApplication())
                return;

            _TestAppointment.LocalDrivingLicenseApplicationID = _LocalDrivingLicenseApplicationID;
            _TestAppointment.TestTypeID = _TestTypeID;
            _TestAppointment.AppointmentDate = dateTimePicker1.Value;
            _TestAppointment.PaidFees = Convert.ToSingle(lblTotalFees.Text);
            _TestAppointment.CreatedByUserID = clsGlobal.CurrentUser.UserID;

            if (_TestAppointment.Save())
            {
                _Mode = enMode.Update;
                MessageBox.Show("Data saved successfully", "Saved",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Error: Data is not saved successfully", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
